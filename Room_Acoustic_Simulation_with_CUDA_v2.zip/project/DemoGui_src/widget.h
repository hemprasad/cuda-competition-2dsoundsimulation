#ifndef WIDGET_H
#define WIDGET_H

#include <QtGui/QWidget>
#include <QPainter>


#endif // WIDGET_H
