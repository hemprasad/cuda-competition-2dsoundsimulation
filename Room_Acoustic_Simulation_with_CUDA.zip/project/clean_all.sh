cd gpu_src
make clean
cd ../cpu_src
make clean
cd ../DemoGui_src
make clean
cd ../
rm -r -f bin
