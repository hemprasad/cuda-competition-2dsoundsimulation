cd gpu_src
make
cd ../cpu_src
make
cd ../DemoGui_src
make
mv MusicSimulation ../bin/
cd ../Demo_src
make

